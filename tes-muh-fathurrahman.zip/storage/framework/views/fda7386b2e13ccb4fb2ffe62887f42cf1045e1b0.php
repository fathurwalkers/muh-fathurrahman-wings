<?php $__env->startPush('css'); ?>
    <style>
        /* .container {
                            height: 800px!important;
                        } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-sm-12 col-md-12 col-lg-12 mt-2 d-flex justify-content-end border border-1 py-2">
            <form action="<?php echo e(route('checkout-product')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_product" value="">
                <button class="btn btn-info btn-md ml-2" id="sendrequest">
                    Total Keranjang Belanja :
                    <span class="badge badge-light py-auto counterbadges" id="counterbadges">0</span>
                </button>
            </form>
        </div>
    </div>

    <div class="row justify-content-center mb-4">

        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4 col-md-4 col-lg-4 mb-2 mb-4">
                <div class="card mb-2" style="width: 12rem;">
                    <img class="card-img-top" style="" src="<?php echo e(asset('assets')); ?>/<?php echo e($item->product_name); ?>.jpg"
                        alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->product_name); ?></h5>
                        <p class="card-text">Rp. <strike><?php echo e(number_format($item->price, 2, ',', '.')); ?></strike></p>
                        <?php
                            $harga_diskon = ($item->discount / 100) * $item->price;
                        ?>
                        <p class="card-text">Rp. <?php echo e(number_format($harga_diskon, 2, ',', '.')); ?></p>
                        <button type="button" class="btn btn-primary counters bukuid" value="<?php echo e($item->id); ?>"">
                            Buy
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <br />
    <br />
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    let array_pinjaman = [];
    var token = $('meta[name="csrf-token"]').attr('content');
    var count = 0;
    var counterbadges = document.getElementById("counterbadges");
    $('.counters').click(function(){
        count++;
        counterbadges.innerHTML = count;
    });
    $("button").click(function() {
        var pinjaman = $(this).val();
        array_pinjaman.push(pinjaman);
        console.log(array_pinjaman);
        console.log(pinjaman);
    });
    $('#sendrequest').click(function() {
        $('input:hidden[name=id_product]').val(array_pinjaman);
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\tes-muh-fathurrahman\resources\views/home/product-list.blade.php ENDPATH**/ ?>