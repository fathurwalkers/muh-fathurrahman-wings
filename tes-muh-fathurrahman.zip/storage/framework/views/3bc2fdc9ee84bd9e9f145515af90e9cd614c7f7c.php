<?php $__env->startPush('css'); ?>
    <style>
        /* .container {
                    height: 800px!important;
                } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row row-cols-1  justify-content-center">

        <div class="col-10 mb-4 btn shadow ">
            <a href="<?php echo e(route('product-list')); ?>">
                <div class="card border-primary ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-primary btn-sm">
                            <i class="bi bi-box-arrow-in-right" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">PRODUCTS</h6>
                    </div>
                </div>
            </a>
        </div>

        

        <div class="col-10 mb-4 btn shadow">
            <a href="#">
                <div class="card border-danger ">
                    <div class="card-body text-left">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="bi bi-123 text-light" style="font-size: 1rem; display:inline-block;"></i>
                            </button>
                            <h6 class="card-title font-weight-bold text-danger"
                                style="font-size: 1rem; display: inline-block; margin-left: 40px;">KELUAR</h6>
                        </form>
                    </div>
                </div>
            </a>
        </div>

        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\tes-muh-fathurrahman\resources\views/home/index.blade.php ENDPATH**/ ?>