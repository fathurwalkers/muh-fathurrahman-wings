<?php $__env->startPush('css'); ?>
    <style>
        /* .container {
                                height: 800px!important;
                            } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row justify-content-center mb-4">

        <div class="row">
            <div class="card">
                <div class="card-body">
                    
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mb-2">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-4 col-md-4 col-lg-4">
                                                <img src="<?php echo e(asset('assets')); ?>/<?php echo e($item->product_name); ?>.jpg" width="80px" alt="">
                                            </div>
                                            <div class="col-sm-8 col-md-8 col-lg-8">
                                                <?php echo e($item['product_name']); ?> <br>
                                                <p class="card-text">Rp. <strike><?php echo e(number_format($item->price, 2, ',', '.')); ?></strike></p>
                                                <?php
                                                    $harga_diskon = ($item->discount / 100) * $item->price;
                                                ?>
                                                <p class="card-text">Rp. <?php echo e(number_format($harga_diskon, 2, ',', '.')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <?php
                                $array_product2 = [];
                            ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $product2 = array_push($array_product2, $item2->id);
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $implode_array_product = implode(",", $array_product2);
                            ?>
                            <form action="<?php echo e(route('proses-checkout', $implode_array_product)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_request">
                                <button type="submit" class="btn btn-success shadow">
                                    CHECKOUT
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    <br />
    <br />
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\tes-muh-fathurrahman\resources\views/home/checkout-product.blade.php ENDPATH**/ ?>