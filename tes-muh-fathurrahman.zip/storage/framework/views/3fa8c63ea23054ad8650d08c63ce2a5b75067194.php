<?php $__env->startSection('title', 'Ujian Kepolisian'); ?>
<?php $__env->startSection('content-prefix', 'Beranda'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Beranda'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card mb-3">
    <div class="card-body">
        <div class="container">
            <div class="row">
                <h4>
                    <b>
                        Product List
                    </b>
                </h4>
            </div>
            <hr />
            <div class="row">
                <div class="table-responsive">
                    <table id="example" class="display table-bordered" style="width:100%">
                        <thead class="thead-dark">
                            <tr>
                                <th>No.</th>
                                <th>Product Name</th>
                                <th>Product Code</th>
                                <th>Price</th>
                                <th>Currency</th>
                                <th>Discount</th>
                                <th>Dimension</th>
                                <th>Unit</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->product_name); ?></td>
                                <td><?php echo e($data->product_code); ?></td>
                                <td><?php echo e($data->price); ?></td>
                                <td><?php echo e($data->currency); ?></td>
                                <td><?php echo e($data->discount); ?></td>
                                <td><?php echo e($data->dimension); ?></td>
                                <td><?php echo e($data->unit); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\tes-muh-fathurrahman\resources\views/dashboard/product-list.blade.php ENDPATH**/ ?>